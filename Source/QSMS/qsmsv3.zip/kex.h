/* 2021-2026 Quantum Resistant Cryptographic Solutions Corporation
 * All Rights Reserved.
 *
 * NOTICE:
 * This software and all accompanying materials are the exclusive property of
 * Quantum Resistant Cryptographic Solutions Corporation (QRCS). The intellectual
 * and technical concepts contained herein are proprietary to QRCS and are
 * protected under applicable Canadian, U.S., and international copyright,
 * patent, and trade secret laws.
 *
 * CRYPTOGRAPHIC ALGORITHMS AND IMPLEMENTATIONS:
 * - This software includes implementations of cryptographic primitives and
 *   algorithms that are standardized or in the public domain, such as AES
 *   and SHA-3, which are not proprietary to QRCS.
 * - This software also includes cryptographic primitives, constructions, and
 *   algorithms designed by QRCS, including but not limited to RCS, SCB, CSX, QMAC, and
 *   related components, which are proprietary to QRCS.
 * - All source code, implementations, protocol compositions, optimizations,
 *   parameter selections, and engineering work contained in this software are
 *   original works of QRCS and are protected under this license.
 *
 * LICENSE AND USE RESTRICTIONS:
 * - This software is licensed under the Quantum Resistant Cryptographic Solutions
 *   Public Research and Evaluation License (QRCS-PREL), 2025-2026.
 * - Permission is granted solely for non-commercial evaluation, academic research,
 *   cryptographic analysis, interoperability testing, and feasibility assessment.
 * - Commercial use, production deployment, commercial redistribution, or
 *   integration into products or services is strictly prohibited without a
 *   separate written license agreement executed with QRCS.
 * - Licensing and authorized distribution are solely at the discretion of QRCS.
 *
 * EXPERIMENTAL CRYPTOGRAPHY NOTICE:
 * Portions of this software may include experimental, novel, or evolving
 * cryptographic designs. Use of this software is entirely at the user's risk.
 *
 * DISCLAIMER:
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE, SECURITY, OR NON-INFRINGEMENT. QRCS DISCLAIMS ALL
 * LIABILITY FOR ANY DIRECT, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 * ARISING FROM THE USE OR MISUSE OF THIS SOFTWARE.
 *
 * FULL LICENSE:
 * This software is subject to the Quantum Resistant Cryptographic Solutions
 * Public Research and Evaluation License (QRCS-PREL), 2025-2026. The complete license terms
 * are provided in the accompanying LICENSE file or at https://www.qrcscorp.ca.
 *
 * Written by: John G. Underhill
 * Contact: contact@qrcscorp.ca
 */

#ifndef QSMP_KEX_H
#define QSMP_KEX_H

#include "qsms.h"

/**
 * \file kex.h
 * \brief QSMP Key Exchange Functions.
 *
 * \details
 * This header file contains the internal key exchange functions for the Quantum Secure Messaging Protocol (QSMP).
 * QSMP supports two key exchange variants:
 * 
 * - **Duplex:** A bidirectional key exchange method that enables mutual authentication and secure session key
 *   establishment. Both parties exchange cryptographic material to derive a shared secret.
 *
 * - **Simplex:** A unidirectional key exchange method where typically the client verifies the server's identity.
 *
 * The file defines internal state structures for both the client and server roles in Duplex and Simplex key exchanges.
 * These structures encapsulate various cryptographic parameters such as key identities, session token hashes,
 * asymmetric keys (for encryption, signing, and verification), shared secrets, and session expiration times.
 *
 * The following internal (non-exportable) functions are declared:
 *
 * - \c qsmp_kex_duplex_server_key_exchange: Executes the server-side Duplex key exchange.
 * - \c qsmp_kex_duplex_client_key_exchange: Executes the client-side Duplex key exchange.
 * - \c qsmp_kex_simplex_server_key_exchange: Executes the server-side Simplex key exchange.
 * - \c qsmp_kex_simplex_client_key_exchange: Executes the client-side Simplex key exchange.
 * - \c qsmp_kex_test: Runs a suite of internal tests to validate the correctness of the key exchange operations.
 *
 * \note These functions and state structures are internal and are not part of the public QSMP API.
 */

/*!
* \def QSMP_KEX_TEST_ENABLED
* \brief Enable to manually test the kex
*/
#define QSMP_KEX_TEST_ENABLED

/**
 * \struct qsmp_kex_simplex_client_state
 * \brief Internal state for the Simplex key exchange (client-side).
 *
 * \details
 * This structure stores the state information for a client involved in a Simplex key exchange.
 * It includes a unique key identity, the remote party's signature verification key, the client's signing key,
 * a session token hash (of size \c QSMP_SIMPLEX_HASH_SIZE), and an expiration timestamp.
 */
typedef struct qsmp_kex_simplex_client_state
{
	uint8_t keyid[QSMP_KEYID_SIZE];							/*!< The key identity string */
	uint8_t rverkey[QSMP_ASYMMETRIC_VERIFY_KEY_SIZE];		/*!< The remote asymmetric signature verification-key */
	uint8_t sigkey[QSMP_ASYMMETRIC_SIGNING_KEY_SIZE];		/*!< The asymmetric signature signing-key */
	uint8_t schash[QSMP_SIMPLEX_HASH_SIZE];				/*!< The session token hash */
	uint8_t verkey[QSMP_ASYMMETRIC_VERIFY_KEY_SIZE];		/*!< The local asymmetric signature verification-key */
	uint64_t expiration;									/*!< The expiration time, in seconds from epoch */
} qsmp_kex_simplex_client_state;

/**
 * \struct qsmp_kex_simplex_server_state
 * \brief Internal state for the Simplex key exchange (server-side).
 *
 * \details
 * This structure holds the server-side state for a Simplex key exchange operation.
 * It includes the key identity, a session token hash, asymmetric keys for encryption and signing,
 * the local verification key, and an expiration time indicating the validity of the session.
 */
typedef struct qsmp_kex_simplex_server_state
{
	uint8_t keyid[QSMP_KEYID_SIZE];							/*!< The key identity string */
	uint8_t schash[QSMP_SIMPLEX_HASH_SIZE];				/*!< The session token hash */
	uint8_t prikey[QSMP_ASYMMETRIC_PRIVATE_KEY_SIZE];		/*!< The asymmetric cipher private key */
	uint8_t pubkey[QSMP_ASYMMETRIC_PUBLIC_KEY_SIZE];		/*!< The asymmetric cipher public key */
	uint8_t sigkey[QSMP_ASYMMETRIC_SIGNING_KEY_SIZE];		/*!< The asymmetric signature signing-key */
	uint8_t verkey[QSMP_ASYMMETRIC_VERIFY_KEY_SIZE];		/*!< The local asymmetric signature verification-key */
	uint64_t expiration;									/*!< The expiration time, in seconds from epoch */
} qsmp_kex_simplex_server_state;

/**
 * \brief Execute the server-side Simplex key exchange.
 *
 * \details
 * This function handles the Simplex key exchange on the server side. It processes the client's connection
 * request, validates the provided cryptographic material, and updates the QSMP connection state with the
 * negotiated session parameters.
 *
 * \param kss A pointer to the simplex server key exchange state structure.
 * \param cns A pointer to the current QSMP connection state.
 *
 * \return Returns a value of type \c qsmp_errors indicating the success or failure of the key exchange.
 *
 * \note This is an internal non-exportable API.
 */
qsmp_errors qsmp_kex_simplex_server_key_exchange(qsmp_kex_simplex_server_state* kss, qsmp_connection_state* cns);

/**
 * \brief Execute the client-side Simplex key exchange.
 *
 * \details
 * This function initiates and completes the Simplex key exchange from the client side.
 * It exchanges the necessary cryptographic keys, verifies the server's identity using the remote verification key,
 * and updates the QSMP connection state with the established session parameters.
 *
 * \param kcs A pointer to the simplex client key exchange state structure.
 * \param cns A pointer to the current QSMP connection state.
 *
 * \return Returns a value of type \c qsmp_errors representing the outcome of the key exchange process.
 *
 * \note This is an internal non-exportable API.
 */
qsmp_errors qsmp_kex_simplex_client_key_exchange(qsmp_kex_simplex_client_state* kcs, qsmp_connection_state* cns);

#if defined(QSMP_KEX_TEST_ENABLED)
/**
 * \brief Run internal tests for the key exchange functions.
 *
 * \details
 * This function executes a suite of internal tests designed to validate the correct operation of the QSMP
 * key exchange mechanisms. The tests include:
 *
 * - Verifying the proper initialization and management of state structures for both Duplex and Simplex modes.
 * - Testing the cryptographic operations involved in key generation, shared secret derivation, and session token hashing.
 * - Ensuring that the key exchange functions correctly update the QSMP connection state.
 *
 * The function returns true if all internal tests pass, confirming the reliability and correctness of the key exchange implementation.
 *
 * \return Returns true if the key exchange tests succeed; otherwise, false.
 *
 * \note This is an internal non-exportable API.
 */
bool qsmp_kex_test(void);
#endif

#endif
